<template>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark" aria-label="Eighth navbar example">
    <div class="container">
      <a class="navbar-brand" href="#">OnlineFilings</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample07" aria-controls="navbarsExample07" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExample07">
        <form role="search">
          <input class="form-control" type="search" placeholder="Search" aria-label="Search">
        </form>
      </div>
    </div>
  </nav>


  <div class="row">
    <div class="col-md-4">
      Projects
        <!-- <TaskItem v-for="(item, index) in taskItems" :key="index" :item="item"></TaskItem> -->



      Add project
    </div>
    <div class="col-md-8">
      <h2>Reading list</h2>
      <TaskItem v-for="(item, index) in taskItems" :key="index" :item="item"></TaskItem>
      Add task
    </div>
  </div>

</template>

<script>

/*import { v4 } from 'uuid'*/
import TaskItem from './Dashboard/TaskItem.vue';
import { Task } from '@/models/Task.js';
import { Tasks } from '@/models/Tasks.js';

export default {
  name: "TheWelcome",
  components: {
    TaskItem
  },
  data: () => {
    return {
      taskItems: new Tasks()

    }
  },
  methods: {
    
  },
  mounted(){
    console.log("thewelcome moujtend", this.taskItems)

    this.taskItems.add(new Task({'name': 'Today taskname1', 'status': 'to-do', 'dueDate': '2024-10-01'}))
    this.taskItems.add(new Task({'name': 'Today taskname1', 'status': 'to-do', 'dueDate': '2024-10-01'}))
    this.taskItems.add(new Task({'name': 'Tomorrow taskname2', 'status': 'done', 'dueDate': '2024-10-02'}))
    this.taskItems.add(new Task({'name': 'Rest taskname3', 'status': 'done', 'dueDate': '2024-10-04'}))
    console.log("this.taskItems", this.taskItems)
  }
}

</script>


