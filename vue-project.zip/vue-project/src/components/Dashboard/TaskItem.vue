<template>
	<div class="form-check">
	  <input class="form-check-input" type="checkbox" :value="item.status == 'to-do' ? false : true" @click="updateStatus">
	  <label class="form-check-label" for="flexCheckDefault">
	    {{ item?.name }} {{ item?.status }}
	  </label>
	  <div>{{ when }}</div>
</div>
</template>

<script>

import { Task } from '@/models/Task.js';

export default {
	name: "TaskItem",
	/*emits: [],*/
	computed: {
		when(){

			const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD

			return new Date(this.item.dueDate) == today ? 'Today' : this.item.dueDate;

		}
		// maybe for the date conversion
	},
	props: {
		item: {
			type: Task,
			required: true
		}
	},
	methods: {
		test(){
			console.log("test", this.item)
		},
		update(){
			console.log("update")
		},

		delete(){
			console.log("delete")
		},

		updateStatus(){
			console.log("updateStatus")
			const newStatus = this.item.status == 'to-do' ? 'done' : 'to-do';
			this.item.updateStatus(newStatus)
			this.$store.dispatch('taskStore/updateStatus', this.item)
		},

	}
}

</script>