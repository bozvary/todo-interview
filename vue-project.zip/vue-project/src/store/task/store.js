// task/store.js

// import api...
console.log("task/store.js")

const state = {
	tasks: {}
};


const mutations = {
	setTask(state, data){
		//TODO:	
	},

	addTask(state, data){
		//TODO:	
	},

	removeTask(state, data){
		//TODO:	
	}
};

const actions = {

	async create({ commit }) {
		// addTask
	},

	async delete({ commit }) {
		// removeTask
	},

	async update({ commit }) {
		// setTask
	},

	async updateStatus({ commit }, params) {
		// setTask
		console.log("updateStatus store", params)
	},

	async findById({ commit, state }) {
		// state.tasks filter by id
	},

	async filterByName({ commit }) {

	},


};

const getters = {

};

export default {
	namespaced: true,
	state,
	mutations,
	actions,
	getters
}