// store/index.js

import { createStore } from 'vuex'

console.log("store/index.js");


import taskStore from './task/store'
import projectStore from './project/store'



// Create a new store instance.
export default createStore({
  modules: {
  	taskStore,
		projectStore
  }
})

