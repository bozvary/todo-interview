// project/store.js

// import api...

console.log("project/store.js")

const state = {
	projects: {}
};


const mutations = {
	setProject(state, data){
		//TODO:	
	},

	addProject(state, data){
		//TODO:	
	},

	removeProject(state, data){
		//TODO:	
	}
};

const actions = {

	async create({ commit }) {
		// addProject
	},

	async delete({ commit }) {
		// removeProject
	},

	async update({ commit }) {
		// setProject
	},


	async findById({ commit, state }) {
		// state.project filter by id
	},

	async filterByName({ commit }) {

	},


};

const getters = {

};

export default {
	namespaced: true,
	state,
	mutations,
	actions,
	getters
}