/*import Task from './Task'*/

import { v4 } from 'uuid'

/*extends Array*/
export class Tasks extends Object{
	constructor(){
		super();
		/*this*/
	}

	add(task){
		console.log("add taks", task)
		const _id = v4();
		task.id = _id;
		this[_id] = task;
	}
}