// models/Project.js

export class Project {
  constructor() {
    
  }

  async create(projectData) {
    const { name, description, status, startDate, dueDate } = projectData;
    const project = { name, description, status, startDate, dueDate, doneDate: null, createdAt: new Date(), updatedAt: new Date() };
    
  }

  async findAll(query, sortOption, perPageNum, skip) {
    
    /*return this.collection.find(query).sort(sortOption).skip(skip).limit(perPageNum).toArray();*/
  }

  async findById(id) {
    
    return ;
  }

  async findOne(query) {
    return ;
  }

  async getTasksByProjectName(projectName) {
    try {
      

    } catch (error) {
      console.error(error);
      res.status(500).send({ error: 'Failed to fetch tasks' });
    }
  }

  async update(id, updateData) {
    
    

    return;
  }

  async delete(id) {
    
    return;
  }

  async updateStatus(id, status, updateFields) {
    
    return; 
  }

  async assignTaskToProject(projectId, taskId) {
    return ;
  }

  async moveTaskToProject(currentProjectId, newProjectId, taskId) {
    return ;
  }
}
