// models/Task.js

export class Task {
  constructor(data) {
    this.id = null
    this.name = data?.name;
    this.status = data?.status;
    this.dueDate = data?.dueDate;
  }

  async create(taskData) {
    /*const { name, description, status, startDate, dueDate } = taskData;
    const project = { name, description, status, startDate, dueDate, doneDate: null, createdAt: new Date(), updatedAt: new Date() };*/
    
  }

  async findAll(query, sortOption, perPageNum, skip) {
    
    /*return this.collection.find(query).sort(sortOption).skip(skip).limit(perPageNum).toArray();*/
  }

  async findById(id) {
    
    return ;
  }

  async findOne(query) {
    return ;
  }

  
  async update(id, updateData) { 
    return;
  }

  async delete(id) {
    
    return;
  }

  async updateStatus(status) {
    console.log("updateStatus newstats", status)
    if (!['to-do', 'done'].includes(status)) {
      console.error('wrong status')
      // can throw exception
    }
    this.status = status;
    return true; 
  }

  async assignTaskToProject(projectId, taskId) {
    return ;
  }

  async moveTaskToProject(currentProjectId, newProjectId, taskId) {
    return ;
  }
}
