
export class Projects extends Array{

}